# Copyright 2025 Amazon Inc

# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.
"""Simple example of adding a coffee maker to the cart.

Usage:
python -m nova_act.samples.order_a_coffee_maker [--record_video]
"""

import fire  # type: ignore

from nova_act import NovaAct


async def main(record_video: bool = False):
    with NovaAct(
        starting_page="https://www.amazon.com",
        record_video=record_video,
    ) as nova:
        await nova.act("search for a coffee maker")
        await nova.act("select the first result")
        await nova.act("scroll down or up until you see 'add to cart' and then click 'add to cart'")


if __name__ == "__main__":
    import asyncio
    fire.Fire(lambda **kwargs: asyncio.run(main(**kwargs)))
